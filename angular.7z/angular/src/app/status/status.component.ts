import { Component, OnInit } from '@angular/core';
import { UpdateService } from '../update.service';
import { Delivery } from 'src/delivery';


@Component({
  selector: 'app-status',
  templateUrl: './status.component.html',
  styleUrls: ['./status.component.css']
})
export class StatusComponent implements OnInit {

  constructor(private updateService : UpdateService) { }

  cap:Delivery;

  ngOnInit() {
   this.cap=new Delivery();
  }
  check(data){
    this.updateService.proStatus(data.proid).subscribe(data=>this.cap=data);
   
   
  }
}